#!/usr/bin/env python3
"""
Notion 同步腳本 - 修正記憶庫 ↔ Notion 雙向同步

此腳本不直接呼叫 Notion API，而是產生 Claude/MCP 可執行的指令。
在 Claude Code 環境中，由 Claude 透過 Notion MCP 執行同步。

使用方式：
  1. Claude 讀取此腳本的邏輯
  2. 根據 correction_memory.json 的內容，批次建立/更新 Notion 頁面
  3. 或從 Notion 拉取最新資料回寫 JSON
"""

import argparse
import json
import os
import sys
from datetime import datetime
from pathlib import Path


def load_memory(memory_path: str) -> dict:
    """載入本地記憶庫"""
    if not os.path.exists(memory_path):
        print(f"❌ 記憶庫不存在: {memory_path}")
        sys.exit(1)
    
    with open(memory_path, "r", encoding="utf-8") as f:
        return json.load(f)


def categorize_correction(wrong: str, correct: str) -> str:
    """自動分類修正項目"""
    deity_keywords = ["菩薩", "佛祖", "元帥", "太子", "財神", "神", "帝", "王爺", "媽祖", "關聖"]
    temple_keywords = ["宮", "廟", "庵", "寺", "壇", "閣", "殿"]
    ritual_keywords = ["供養", "法會", "科儀", "誦經", "超拔", "普度", "犒軍", "過火", "開光", "安座"]
    shuwen_keywords = ["疏文", "呈文", "表文", "奏疏", "信士", "弟子", "叩謝", "恭請"]
    offering_keywords = ["香", "金紙", "供品", "花果", "燈", "燭"]
    
    for kw in deity_keywords:
        if kw in correct:
            return "神明名號"
    for kw in temple_keywords:
        if kw in correct:
            return "廟宇名稱"
    for kw in ritual_keywords:
        if kw in correct:
            return "儀式用語"
    for kw in shuwen_keywords:
        if kw in correct:
            return "疏文術語"
    for kw in offering_keywords:
        if kw in correct:
            return "供品相關"
    
    return "一般用語"


def generate_notion_pages(memory_path: str, output_path: str = None) -> list:
    """
    從 JSON 記憶庫產生 Notion 頁面資料
    輸出格式適合 Claude 透過 Notion MCP notion-create-pages 執行
    
    Returns:
        list of page data dicts
    """
    memory = load_memory(memory_path)
    corrections = memory.get("corrections", {})
    
    pages = []
    for wrong, correct in corrections.items():
        category = categorize_correction(wrong, correct)
        page = {
            "properties": {
                "錯誤詞": wrong,
                "正確詞": correct,
                "類別": category,
                "來源": "預載術語",
                "出現次數": 0,
                "備註": ""
            }
        }
        pages.append(page)
    
    print(f"📋 產生 {len(pages)} 筆 Notion 頁面資料")
    
    # 按類別統計
    categories = {}
    for p in pages:
        cat = p["properties"]["類別"]
        categories[cat] = categories.get(cat, 0) + 1
    
    print("📊 類別分佈:")
    for cat, count in sorted(categories.items(), key=lambda x: -x[1]):
        print(f"   {cat}: {count} 筆")
    
    if output_path:
        with open(output_path, "w", encoding="utf-8") as f:
            json.dump(pages, f, ensure_ascii=False, indent=2)
        print(f"💾 已儲存: {output_path}")
    
    return pages


def generate_sync_instructions(memory_path: str, data_source_id: str = None) -> str:
    """
    產生供 Claude 執行的同步指令
    
    Args:
        memory_path: 本地記憶庫路徑
        data_source_id: Notion 資料庫的 data_source_id
    
    Returns:
        markdown 格式的同步指令
    """
    memory = load_memory(memory_path)
    corrections = memory.get("corrections", {})
    
    instructions = []
    instructions.append("# Notion 同步指令\n")
    instructions.append(f"記憶庫: {memory_path}")
    instructions.append(f"修正規則: {len(corrections)} 條")
    instructions.append(f"目標 data_source_id: {data_source_id or '待建立'}\n")
    
    if not data_source_id:
        instructions.append("## Step 1: 建立 Notion 資料庫\n")
        instructions.append("使用 Notion MCP `notion-create-database`:")
        instructions.append('```')
        instructions.append(json.dumps({
            "title": "🎤 語音辨識修正記憶庫",
            "description": "語音辨識除錯記憶系統 - 記錄修正對應",
            "schema": 'CREATE TABLE ("錯誤詞" TITLE, "正確詞" RICH_TEXT, "類別" SELECT(\'神明名號\':purple, \'廟宇名稱\':blue, \'儀式用語\':orange, \'疏文術語\':red, \'供品相關\':green, \'台語音譯\':brown, \'一般用語\':default), "來源" SELECT(\'Whisper辨識錯誤\':blue, \'手動新增\':green, \'預載術語\':gray), "出現次數" NUMBER, "狀態" STATUS, "備註" RICH_TEXT, "新增日期" CREATED_TIME)'
        }, ensure_ascii=False, indent=2))
        instructions.append('```\n')
    
    instructions.append("## Step 2: 批次新增修正記錄\n")
    instructions.append("使用 Notion MCP `notion-create-pages` (每批最多 100 筆):\n")
    
    # 分批
    batch_size = 50
    items = list(corrections.items())
    for batch_num in range(0, len(items), batch_size):
        batch = items[batch_num:batch_num + batch_size]
        instructions.append(f"### 批次 {batch_num // batch_size + 1} ({len(batch)} 筆)\n")
        
        pages = []
        for wrong, correct in batch:
            category = categorize_correction(wrong, correct)
            pages.append({
                "properties": {
                    "錯誤詞": wrong,
                    "正確詞": correct,
                    "類別": category,
                    "來源": "預載術語",
                    "出現次數": 0
                }
            })
        
        instructions.append(f"共 {len(pages)} 筆資料待新增\n")
    
    return "\n".join(instructions)


def notion_to_json(notion_data: list, output_path: str) -> dict:
    """
    從 Notion 查詢結果轉換回 JSON 記憶庫格式
    
    Args:
        notion_data: Notion 查詢結果（list of dicts with 錯誤詞, 正確詞）
        output_path: 輸出 JSON 路徑
    
    Returns:
        記憶庫 dict
    """
    memory = {
        "version": "1.0",
        "last_updated": datetime.now().isoformat(),
        "corrections": {},
        "context_rules": [],
        "always_prefer": []
    }
    
    for item in notion_data:
        wrong = item.get("錯誤詞", "").strip()
        correct = item.get("正確詞", "").strip()
        if wrong and correct:
            memory["corrections"][wrong] = correct
            # 自動加入 always_prefer
            if correct not in memory["always_prefer"]:
                memory["always_prefer"].append(correct)
    
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(memory, f, ensure_ascii=False, indent=2)
    
    print(f"✅ 從 Notion 同步 {len(memory['corrections'])} 條修正到: {output_path}")
    return memory


def main():
    parser = argparse.ArgumentParser(description="Notion 同步工具")
    subparsers = parser.add_subparsers(dest="command", help="同步方向")
    
    # JSON → Notion
    to_notion = subparsers.add_parser("to-notion", help="JSON 記憶庫 → Notion")
    to_notion.add_argument("--memory", "-m", required=True, help="記憶庫 JSON 路徑")
    to_notion.add_argument("--data-source-id", "-d", help="Notion data_source_id")
    to_notion.add_argument("--output", "-o", help="輸出頁面資料 JSON")
    
    # Notion → JSON
    from_notion = subparsers.add_parser("from-notion", help="Notion → JSON 記憶庫")
    from_notion.add_argument("--input", "-i", required=True, help="Notion 查詢結果 JSON")
    from_notion.add_argument("--output", "-o", required=True, help="輸出記憶庫 JSON 路徑")
    
    # 產生指令
    gen_inst = subparsers.add_parser("instructions", help="產生同步指令")
    gen_inst.add_argument("--memory", "-m", required=True, help="記憶庫 JSON 路徑")
    gen_inst.add_argument("--data-source-id", "-d", help="Notion data_source_id")
    
    args = parser.parse_args()
    
    if args.command == "to-notion":
        pages = generate_notion_pages(args.memory, args.output)
    elif args.command == "from-notion":
        with open(args.input, "r", encoding="utf-8") as f:
            notion_data = json.load(f)
        notion_to_json(notion_data, args.output)
    elif args.command == "instructions":
        print(generate_sync_instructions(args.memory, args.data_source_id))
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
