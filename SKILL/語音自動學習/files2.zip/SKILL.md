---
name: speech-correction-memory
description: 語音辨識除錯記憶系統。將音檔或即時語音轉成文字，並維護一個「修正記憶庫」——使用者糾正過的錯字會被記住，下次自動替換成正確的字。特別針對台灣國語、台語/閩南語、佛教道教宗教術語優化。適用場景包括：(1) 口述疏文內容轉文字 (2) 錄好的音檔轉文字 (3) 即時語音輸入。當使用者提到「語音辨識」、「語音轉文字」、「STT」、「speech to text」、「錄音轉文字」、「口述轉文字」、「語音除錯」、「語音修正」、「Whisper」時觸發此 Skill。也適用於使用者上傳音檔（.wav, .mp3, .m4a, .ogg, .flac）需要轉文字的場景。
---

# 語音辨識除錯記憶系統 (Speech Correction Memory)

## 概述

本 Skill 提供一套完整的語音辨識＋智能除錯＋記憶學習流程：

1. **語音辨識**：使用 OpenAI Whisper 將音檔轉為文字
2. **記憶庫自動替換**：載入先前累積的修正對應表，自動替換已知錯誤
3. **Claude 智能校正**：利用上下文和宗教術語知識做第二層校正
4. **使用者確認＋除錯**：使用者檢查結果，標記剩餘錯誤
5. **記憶庫更新**：新修正自動寫入記憶庫（JSON + 可選 Notion 同步）

## 環境準備

首次使用前，執行安裝腳本：

```bash
bash /path/to/skill/scripts/setup.sh
```

這會安裝 `openai-whisper`、`ffmpeg`、`jieba` 等必要套件。

## 核心流程

### Step 1：接收輸入

根據使用者的輸入類型判斷：

- **上傳音檔**（.wav/.mp3/.m4a/.ogg/.flac）→ 直接處理
- **提供錄音路徑** → 讀取該路徑
- **即時語音** → 提示使用者先錄音再上傳（Claude.ai 環境限制）
- **已有辨識文字需要校正** → 跳過辨識步驟，直接進入校正

### Step 2：Whisper 辨識

執行辨識腳本：

```bash
python /path/to/skill/scripts/transcribe.py \
  --input "<音檔路徑>" \
  --language "zh" \
  --model "large-v3" \
  --output "/home/claude/transcription_raw.txt"
```

參數說明：
- `--language`：`zh`（中文）、`nan`（閩南語/台語，Whisper 支援有限，建議用 zh 再後處理）
- `--model`：`tiny`/`base`/`small`/`medium`/`large-v3`，依音檔品質和速度需求選擇
- 預設使用 `medium` 平衡速度與品質；宗教術語多時建議 `large-v3`

### Step 3：載入修正記憶庫並自動替換

```bash
python /path/to/skill/scripts/apply_corrections.py \
  --input "/home/claude/transcription_raw.txt" \
  --memory "/path/to/skill/assets/correction_memory.json" \
  --output "/home/claude/transcription_corrected.txt"
```

記憶庫格式（`correction_memory.json`）：

```json
{
  "version": "1.0",
  "last_updated": "2026-03-21T10:00:00+08:00",
  "corrections": {
    "關音菩薩": "觀音菩薩",
    "太子貴貴功": "太子貴貴宮",
    "五路材神": "五路財神",
    "書文": "疏文",
    "結圓供養": "結緣供養",
    "中壇元帥": "中壇元帥",
    "金山材神廟": "金山財神廟"
  },
  "context_rules": [
    {
      "pattern": "供養.*材神",
      "replace_target": "材神",
      "replace_with": "財神",
      "note": "在供養相關語境中，材→財"
    }
  ],
  "always_prefer": [
    "觀音菩薩", "疏文", "太子貴貴宮", "五路財神",
    "中壇元帥", "哪吒三太子", "結緣供養", "香供養",
    "天赦日", "板橋慈惠宮", "新莊地藏庵", "金山財神廟",
    "明心福旺閣"
  ]
}
```

記憶庫的三層結構：
- **corrections**：直接的「錯→對」對應，最優先
- **context_rules**：需要上下文才能判斷的替換規則（用正則匹配）
- **always_prefer**：偏好詞彙表，提示 Claude 校正時優先使用這些寫法

### Step 4：Claude 智能校正

將 Step 3 的輸出加上 always_prefer 詞彙表，請 Claude 做語境校正。

Prompt 範本：

```
你是一位台灣民間信仰和佛道教儀式的文字校對專家。

以下是語音辨識後經過初步修正的文字，請根據上下文進一步校正：
- 修正明顯的同音字錯誤
- 確保宗教術語、神明名號、廟宇名稱使用正確的字
- 不要改動原意，只修正明顯的辨識錯誤

偏好詞彙表（優先使用這些寫法）：
{從 always_prefer 載入}

待校正文字：
---
{transcription_corrected.txt 的內容}
---

請輸出校正後的完整文字，並在文末列出你做了哪些修改（格式：「原文」→「修正」）。
```

### Step 5：使用者確認與除錯

將校正結果呈現給使用者，請使用者確認。如果使用者指出還有錯誤：

1. 記錄使用者的修正（「錯字→正確字」）
2. 詢問使用者：「要將這個修正加入記憶庫嗎？」
3. 如果確認，更新記憶庫

### Step 6：更新記憶庫

```bash
python /path/to/skill/scripts/update_memory.py \
  --memory "/path/to/skill/assets/correction_memory.json" \
  --add '{"錯字": "正確字"}' \
  --prefer '["新偏好詞"]'
```

更新後自動備份舊版本到 `assets/backups/` 目錄。

### Step 7：同步到 Notion

修正記憶庫支援 JSON ↔ Notion 雙向同步。Notion 資料庫方便視覺化管理和手動編輯，JSON 則是腳本自動替換的引擎。

#### 7a. 首次設定：建立 Notion 資料庫

使用 Notion MCP `notion-create-database` 建立資料庫：

```json
{
  "title": "🎤 語音辨識修正記憶庫",
  "description": "語音辨識除錯記憶系統 - 記錄修正對應，供 Whisper 後處理自動替換",
  "schema": "CREATE TABLE (\"錯誤詞\" TITLE, \"正確詞\" RICH_TEXT, \"類別\" SELECT('神明名號':purple, '廟宇名稱':blue, '儀式用語':orange, '疏文術語':red, '供品相關':green, '台語音譯':brown, '一般用語':default), \"來源\" SELECT('Whisper辨識錯誤':blue, '手動新增':green, '預載術語':gray), \"出現次數\" NUMBER, \"狀態\" STATUS, \"備註\" RICH_TEXT, \"新增日期\" CREATED_TIME)"
}
```

建立後，記下回傳的 `data_source_id`（格式如 `collection://xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx`），後續同步需要用到。

欄位說明：
- **錯誤詞**（Title）：Whisper 辨識出的錯字
- **正確詞**（Rich Text）：使用者修正後的正確字
- **類別**（Select）：自動分類 — 神明名號/廟宇名稱/儀式用語/疏文術語/供品相關/台語音譯/一般用語
- **來源**（Select）：修正的來源 — Whisper辨識錯誤/手動新增/預載術語
- **出現次數**（Number）：該錯誤被捕捉到的次數，用於判斷哪些是高頻錯誤
- **狀態**（Status）：管理修正的生命週期（預設：Not started/In progress/Done）
- **備註**（Rich Text）：額外說明，例如「只在特定語境出現」
- **新增日期**（Created Time）：自動記錄

#### 7b. JSON → Notion 同步（推送修正到 Notion）

當本地 JSON 記憶庫更新後，將新增的修正同步到 Notion：

```bash
python /path/to/skill/scripts/notion_sync.py to-notion \
  --memory "/path/to/skill/assets/correction_memory.json" \
  --output "/home/claude/notion_pages_to_create.json"
```

這會產生格式化的頁面資料。然後 Claude 使用 Notion MCP `notion-create-pages` 批次建立：

```json
{
  "parent": {"data_source_id": "<你的 data_source_id>"},
  "pages": [
    {
      "properties": {
        "錯誤詞": "關音菩薩",
        "正確詞": "觀音菩薩",
        "類別": "神明名號",
        "來源": "Whisper辨識錯誤",
        "出現次數": 1
      }
    }
  ]
}
```

注意：每次呼叫最多 100 筆，超過的需分批。`notion_sync.py` 會自動分批產出。

#### 7c. Notion → JSON 同步（從 Notion 拉回修正）

如果使用者在 Notion 上手動新增或修改了修正記錄，可以反向同步回 JSON：

1. 使用 Notion MCP `notion-query-database-view` 查詢所有記錄
2. 將結果傳給 `notion_sync.py from-notion` 轉換回 JSON 格式

```bash
python /path/to/skill/scripts/notion_sync.py from-notion \
  --input "/home/claude/notion_export.json" \
  --output "/path/to/skill/assets/correction_memory.json"
```

#### 7d. 自動同步觸發時機

在以下時機自動觸發 Notion 同步：
- **使用者確認新修正時**：Step 5 修正確認後，同時更新 JSON 和 Notion
- **批次辨識完成後**：如果產生了新的修正，批次同步到 Notion
- **使用者主動要求**：使用者說「同步到 Notion」或「從 Notion 更新」時

#### 7e. 自動分類邏輯

`notion_sync.py` 內建自動分類，根據正確詞的內容判斷類別：

| 關鍵字包含 | 分類 |
|-----------|------|
| 菩薩、佛祖、元帥、太子、財神、神、帝、王爺、媽祖 | 神明名號 |
| 宮、廟、庵、寺、壇、閣、殿 | 廟宇名稱 |
| 供養、法會、科儀、超拔、普度、犒軍、過火、開光 | 儀式用語 |
| 疏文、呈文、信士、弟子、叩謝、恭請 | 疏文術語 |
| 香、金紙、供品、花果、燈、燭 | 供品相關 |
| 其他 | 一般用語 |

如果自動分類不準確，使用者可在 Notion 中手動修改類別。

#### 7f. 建議的 Notion 視圖

建立資料庫後，建議新增以下視圖方便管理：

1. **全部修正（Table）**：預設視圖，按新增日期排序
2. **依類別（Board）**：GROUP BY 類別，一目了然各類修正數量
3. **高頻錯誤（Table）**：FILTER 出現次數 > 3，SORT BY 出現次數 DESC
4. **最近新增（Table）**：SORT BY 新增日期 DESC，快速檢視最新修正

使用 Notion MCP `notion-create-view` 建立這些視圖。

## 重要注意事項

- **台語處理**：Whisper 對純台語的支援有限。建議先用 `zh` 模式辨識，再靠記憶庫和 Claude 校正台語用詞。
- **記憶庫路徑**：預設在 skill 的 `assets/correction_memory.json`。如果使用者有自己的路徑偏好，尊重使用者設定。
- **備份**：每次修改記憶庫前自動備份，保留最近 10 個版本。
- **批次處理**：如果有多個音檔需要處理，用 `scripts/batch_transcribe.py` 一次處理整個資料夾。
- **隱私**：音檔和辨識結果只存在使用者本地，不上傳到外部服務（Whisper 在本地執行）。

## 檔案結構

```
speech-correction-memory/
├── SKILL.md                          ← 你正在看的這個
├── scripts/
│   ├── setup.sh                      ← 環境安裝
│   ├── transcribe.py                 ← Whisper 辨識
│   ├── apply_corrections.py          ← 記憶庫自動替換
│   ├── update_memory.py              ← 更新記憶庫
│   ├── batch_transcribe.py           ← 批次處理多音檔
│   └── notion_sync.py               ← Notion 雙向同步
├── assets/
│   ├── correction_memory.json        ← 修正記憶庫（核心）
│   ├── backups/                      ← 記憶庫備份
│   └── religious_terms_base.json     ← 預設宗教術語表
└── references/
    └── whisper_tips.md               ← Whisper 使用技巧與限制
```
